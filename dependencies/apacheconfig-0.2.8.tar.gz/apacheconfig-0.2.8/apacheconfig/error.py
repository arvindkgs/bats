#
# This file is part of apacheconfig software.
#
# Copyright (c) 2018-2019, Ilya Etingof <etingof@gmail.com>
# License: https://github.com/etingof/apacheconfig/LICENSE.rst
#


class ApacheConfigError(Exception):
    pass


class ConfigFileReadError(ApacheConfigError):
    pass
